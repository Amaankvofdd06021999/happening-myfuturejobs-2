import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { AIPanel } from "@/components/AIPanel";
import { employerNav } from "@/lib/nav";
import { employerUser, candidates } from "@/lib/mock";
import { KPITile, SectionTitle, Badge } from "@/components/ui-bits";
import { Briefcase, Users, Calendar, Sparkles, ArrowRight, Eye, AlertTriangle, CheckCircle2 } from "lucide-react";

export const Route = createFileRoute("/employer/")({
  head: () => ({ meta: [{ title: "Employer dashboard — MYFutureJobs" }] }),
  component: Page,
});

function Page() {
  return (
    <AppShell
      nav={employerNav}
      user={employerUser}
      rightPanel={
        <AIPanel
          title="Hiring Assistant"
          subtitle="Recommended actions"
          why={<p>Suggestions are scored against your last 30 vacancies and current talent pool depth.</p>}
        >
          <div className="space-y-3">
            <div className="rounded-[10px] bg-emphasis-soft p-3">
              <div className="text-[11px] font-600 uppercase tracking-wider text-emphasis">Today's priority</div>
              <p className="mt-1 text-[12px]">3 strong matches pending review for <b>Software Engineer · KL</b>.</p>
              <Link to="/employer/fit-match" className="mt-2 inline-flex h-8 items-center rounded-[8px] grad-orange px-3 text-[12px] font-600 text-white">Open shortlist →</Link>
            </div>
            <div className="space-y-2">
              {[
                { t: "Run bias check on 'Sales Manager' JD", to: "/employer/bias" },
                { t: "Generate interview pack for Aisyah R.", to: "/employer/interview" },
                { t: "Improve JD: 'Brand Specialist' score 64 → 82", to: "/employer/jd-analysis" },
              ].map((s) => (
                <Link key={s.t} to={s.to} className="flex items-center justify-between rounded-[10px] border border-border px-3 py-2 text-[12px] hover:border-primary hover:bg-primary-soft">
                  <span>{s.t}</span><ArrowRight className="h-3.5 w-3.5"/>
                </Link>
              ))}
            </div>
          </div>
        </AIPanel>
      }
    >
      <div className="mb-6">
        <div className="text-[12px] font-600 uppercase tracking-wider text-emphasis">Petronas Digital</div>
        <h1 className="text-[28px] font-700 tracking-tight">Hiring at a glance</h1>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <KPITile label="Open vacancies" value="14" delta="+2 this week" icon={<Briefcase className="h-4 w-4"/>}/>
        <KPITile label="Candidates in pipeline" value="248" delta="+38 last 7d" icon={<Users className="h-4 w-4"/>}/>
        <KPITile label="Interviews this week" value="22" delta="3 today" icon={<Calendar className="h-4 w-4"/>}/>
        <KPITile label="Avg. Fit-Match score" value="84" delta="Up from 79 last month" emphasis gradient icon={<Sparkles className="h-4 w-4"/>}/>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-[1.3fr_1fr]">
        <div className="rounded-[12px] border border-border bg-card p-5 shadow-card">
          <SectionTitle title="Active vacancies" action={<Link to="/employer/vacancies" className="text-sm font-600 text-primary">View all →</Link>}/>
          <div className="space-y-2">
            {[
              { t: "Software Engineer (Backend)", a: 86, n: 12, b: 82 },
              { t: "Sales Manager — KL", a: 42, n: 5, b: 64 },
              { t: "Data Analyst", a: 33, n: 8, b: 79 },
              { t: "Brand Specialist", a: 51, n: 4, b: 71 },
            ].map((v) => (
              <div key={v.t} className="grid grid-cols-[1.5fr_repeat(3,1fr)_auto] items-center gap-3 rounded-[10px] border border-border p-3 text-[13px]">
                <div className="font-600">{v.t}</div>
                <div><span className="text-muted-foreground">Applicants </span><b className="num">{v.a}</b></div>
                <div><span className="text-muted-foreground">New </span><b className="num">{v.n}</b></div>
                <div className="flex items-center gap-1"><Sparkles className="h-3 w-3 text-emphasis"/><span className="num font-600">{v.b}</span><span className="text-muted-foreground"> JD</span></div>
                <button aria-label="Open" className="text-muted-foreground"><Eye className="h-4 w-4"/></button>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-[12px] border border-border bg-card p-5 shadow-card">
          <SectionTitle title="Top fit-matches today" action={<Badge tone="ai"><Sparkles className="h-3 w-3"/> AI</Badge>}/>
          <ul className="space-y-3">
            {candidates.slice(0,4).map((c) => (
              <li key={c.id} className="flex items-center gap-3 rounded-[10px] border border-border p-3">
                <img src={c.avatar} alt="" className="h-10 w-10 rounded-full object-cover"/>
                <div className="flex-1 min-w-0">
                  <div className="truncate text-[13px] font-600">{c.name}</div>
                  <div className="truncate text-[11px] text-muted-foreground">{c.role} · {c.exp}</div>
                </div>
                <div className="text-right">
                  <div className="num text-[16px] font-600 text-emphasis">{c.fit}</div>
                  <div className="text-[10px] text-muted-foreground">{c.top}</div>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <div className="rounded-[12px] border border-border bg-card p-5 shadow-card">
          <SectionTitle title="Bias alerts"/>
          <ul className="space-y-2 text-[13px]">
            <li className="flex items-center gap-2 rounded-[8px] border border-border p-3"><AlertTriangle className="h-4 w-4 text-[var(--warning)]"/> "Energetic" — age-coded in 'Sales' JD</li>
            <li className="flex items-center gap-2 rounded-[8px] border border-border p-3"><AlertTriangle className="h-4 w-4 text-[var(--warning)]"/> "Rockstar" — gender-coded in 'Engineer' JD</li>
            <li className="flex items-center gap-2 rounded-[8px] border border-border p-3"><CheckCircle2 className="h-4 w-4 text-[var(--success)]"/> 9 JDs clean</li>
          </ul>
        </div>
        <div className="rounded-[12px] border border-border bg-card p-5 shadow-card lg:col-span-2">
          <SectionTitle title="Funnel · last 30 days"/>
          <div className="grid grid-cols-5 items-end gap-2 h-44">
            {[
              {l:"Sourced",v:90,n:482},
              {l:"Screened",v:62,n:268},
              {l:"Interview",v:38,n:112},
              {l:"Offer",v:18,n:36},
              {l:"Hired",v:10,n:18},
            ].map((s, i) => (
              <div key={s.l} className="flex h-full flex-col justify-end">
                <div className="num text-center text-[12px] font-600">{s.n}</div>
                <div className={`mt-1 rounded-t-md ${i === 4 ? "grad-orange" : "bg-primary"}`} style={{ height: `${s.v}%` }} />
                <div className="mt-2 text-center text-[11px] text-muted-foreground">{s.l}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </AppShell>
  );
}
