import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { employerNav } from "@/lib/nav";
import { employerUser } from "@/lib/mock";
import { Badge, SectionTitle } from "@/components/ui-bits";
import { Plus, Sparkles } from "lucide-react";

export const Route = createFileRoute("/employer/vacancies")({
  head: () => ({ meta: [{ title: "Vacancies — MYFutureJobs" }] }),
  component: Page,
});

const rows = [
  { t: "Software Engineer (Backend)", l: "KL · Hybrid", s: "Active", a: 86, b: 82, d: "2d" },
  { t: "Sales Manager — KL", l: "KL · On-site", s: "Active", a: 42, b: 64, d: "5d" },
  { t: "Data Analyst", l: "Cyberjaya · Hybrid", s: "Active", a: 33, b: 79, d: "1w" },
  { t: "Brand Specialist", l: "KL · Hybrid", s: "Draft", a: 0, b: 71, d: "—" },
  { t: "Operations Lead", l: "Penang · On-site", s: "Paused", a: 18, b: 76, d: "3w" },
];

function Page() {
  return (
    <AppShell nav={employerNav} user={employerUser}>
      <div className="mb-6 flex items-end justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-[28px] font-700 tracking-tight">Vacancies</h1>
          <p className="mt-1 text-sm text-muted-foreground">5 vacancies · Verified employer</p>
        </div>
        <button className="inline-flex h-10 items-center gap-1.5 rounded-[10px] bg-primary px-4 text-sm font-600 text-primary-foreground"><Plus className="h-4 w-4"/> New vacancy</button>
      </div>

      <div className="overflow-hidden rounded-[12px] border border-border bg-card shadow-card">
        <table className="w-full text-[13px]">
          <thead className="bg-inset text-[11px] uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="px-4 py-3 text-left">Role</th>
              <th className="px-4 py-3 text-left">Location</th>
              <th className="px-4 py-3 text-left">Status</th>
              <th className="px-4 py-3 text-right">Applicants</th>
              <th className="px-4 py-3 text-right">JD score</th>
              <th className="px-4 py-3 text-left">Posted</th>
              <th className="px-4 py-3"></th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.t} className="border-t border-border">
                <td className="px-4 py-3 font-600">{r.t}</td>
                <td className="px-4 py-3 text-muted-foreground">{r.l}</td>
                <td className="px-4 py-3"><Badge tone={r.s === "Active" ? "success" : r.s === "Draft" ? "default" : "warning"}>{r.s}</Badge></td>
                <td className="px-4 py-3 text-right num">{r.a}</td>
                <td className="px-4 py-3 text-right">
                  <span className={`num inline-flex items-center gap-1 font-600 ${r.b < 70 ? "text-emphasis" : "text-primary"}`}>
                    <Sparkles className="h-3 w-3"/> {r.b}
                  </span>
                </td>
                <td className="px-4 py-3 text-muted-foreground">{r.d}</td>
                <td className="px-4 py-3 text-right">
                  <Link to="/employer/jd-analysis" className="text-[12px] font-600 text-primary">Open →</Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </AppShell>
  );
}
