import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { jobseekerNav } from "@/lib/nav";
import { jobseekerUser } from "@/lib/mock";
import { Badge, SectionTitle } from "@/components/ui-bits";

export const Route = createFileRoute("/jobseeker/applications")({
  head: () => ({ meta: [{ title: "Applications — MYFutureJobs" }] }),
  component: Page,
});

const stages = [
  { id: "applied", label: "Applied", color: "var(--muted-foreground)", items: [
    { c: "Maybank", r: "Digital Campaign Lead", d: "2 Feb" },
    { c: "Shopee", r: "Marketing Exec", d: "4 Feb" },
    { c: "Touch n Go", r: "Brand Manager", d: "5 Feb" },
  ]},
  { id: "interview", label: "Interview", color: "var(--primary)", items: [
    { c: "Petronas Digital", r: "Sr. Marketing Exec", d: "Thu 14 Feb · 10:00" },
    { c: "AirAsia", r: "Brand Specialist", d: "Mon 18 Feb · 14:30" },
  ]},
  { id: "kiv", label: "KIV", color: "var(--warning)", items: [
    { c: "Astro", r: "Content Strategist", d: "Review 14 Feb" },
  ]},
  { id: "outcome", label: "Hired / Reject", color: "var(--success)", items: [
    { c: "Grab", r: "Growth Marketer", d: "Offer · accepted" },
  ]},
];

function Page() {
  return (
    <AppShell nav={jobseekerNav} user={jobseekerUser}>
      <div className="mb-6">
        <h1 className="text-[28px] font-700 tracking-tight">Application tracker</h1>
        <p className="mt-1 text-sm text-muted-foreground">Drag to update, or click any card for details.</p>
      </div>

      <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
        {stages.map((s) => (
          <section key={s.id} className="rounded-[12px] border border-border bg-card p-4 shadow-card">
            <SectionTitle title={`${s.label}  ·  ${s.items.length}`} />
            <div className="space-y-2">
              {s.items.map((i) => (
                <article key={i.r} className="rounded-[10px] border border-border bg-background p-3">
                  <div className="text-[13px] font-600">{i.r}</div>
                  <div className="text-[12px] text-muted-foreground">{i.c}</div>
                  <div className="mt-2 flex items-center justify-between">
                    <span className="text-[11px] text-muted-foreground">{i.d}</span>
                    <Badge tone={s.id === "interview" ? "primary" : s.id === "kiv" ? "warning" : s.id === "outcome" ? "success" : "default"}>
                      {s.label}
                    </Badge>
                  </div>
                </article>
              ))}
            </div>
          </section>
        ))}
      </div>
    </AppShell>
  );
}
