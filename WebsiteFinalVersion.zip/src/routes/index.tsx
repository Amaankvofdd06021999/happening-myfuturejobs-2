import { createFileRoute, Link } from "@tanstack/react-router";
import { Search, MapPin, Sparkles, Briefcase, Building2, GraduationCap, Calendar, Award, ArrowRight, CheckCircle2, BarChart3, Users, ShieldCheck } from "lucide-react";
import { Logo } from "@/components/Logo";
import { ThemeToggle } from "@/components/ThemeToggle";
import { FloatingChatbot } from "@/components/FloatingChatbot";
import { Badge } from "@/components/ui-bits";
import teamHero from "@/assets/team-hero.jpg";
import person1 from "@/assets/person-1.jpg";
import person2 from "@/assets/person-2.jpg";
import person3 from "@/assets/person-3.jpg";
import person4 from "@/assets/person-4.jpg";
import eventCarnival from "@/assets/event-carnival.jpg";
import eventTraining from "@/assets/event-training.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "MYFutureJobs — Find work that fits you" },
      { name: "description", content: "Malaysia's national employment portal. AI-powered job matching, verified employers, training & rewards." },
    ],
  }),
  component: Home,
});

function Home() {
  return (
    <div className="min-h-dvh bg-background">
      {/* Top nav */}
      <header className="sticky top-0 z-40 border-b border-border bg-background/90 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-[1280px] items-center gap-6 px-4 lg:px-8">
          <Logo />
          <nav className="ml-6 hidden items-center gap-6 text-sm text-muted-foreground md:flex">
            <a href="#jobs" className="hover:text-foreground">Find jobs</a>
            <a href="#employers" className="hover:text-foreground">For employers</a>
            <a href="#programs" className="hover:text-foreground">Programs & events</a>
            <a href="#services" className="hover:text-foreground">Career services</a>
          </nav>
          <div className="ml-auto flex items-center gap-2">
            <ThemeToggle />
            <Link to="/signin" className="hidden h-10 items-center rounded-[10px] px-4 text-sm font-600 text-foreground hover:bg-inset sm:inline-flex">
              Sign in
            </Link>
            <Link to="/signin" className="inline-flex h-10 items-center rounded-[10px] bg-primary px-4 text-sm font-600 text-primary-foreground hover:opacity-95">
              Create account
            </Link>
          </div>
        </div>
      </header>

      {/* HERO */}
      <section className="relative overflow-hidden border-b border-border">
        <div className="mx-auto grid max-w-[1280px] gap-10 px-4 py-14 lg:grid-cols-[1.1fr_1fr] lg:gap-12 lg:px-8 lg:py-20">
          <div>
            <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1.5 text-[12px] font-600">
              <span className="h-1.5 w-1.5 rounded-full bg-emphasis" />
              National employment portal · Powered by PERKESO
            </div>
            <h1 className="text-[44px] font-700 leading-[1.05] tracking-tight lg:text-[60px]">
              Find work that <span className="text-emphasis">fits you</span>, not just any job.
            </h1>
            <p className="mt-5 max-w-[560px] text-[17px] leading-relaxed text-muted-foreground">
              Smart matching, AI career coaching, verified Malaysian employers, and pathways into training — all in one place.
            </p>

            {/* search */}
            <div id="jobs" className="mt-7 rounded-[14px] border border-border bg-card p-2 shadow-hero">
              <div className="grid gap-2 md:grid-cols-[1.5fr_1fr_auto]">
                <label className="flex items-center gap-2 rounded-[10px] bg-inset px-3">
                  <Search className="h-4 w-4 text-muted-foreground" />
                  <input placeholder="Job title, skill or company" className="h-12 w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground" />
                </label>
                <label className="flex items-center gap-2 rounded-[10px] bg-inset px-3">
                  <MapPin className="h-4 w-4 text-muted-foreground" />
                  <input placeholder="Kuala Lumpur, Selangor…" className="h-12 w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground" />
                </label>
                <button className="h-12 rounded-[10px] grad-orange px-6 text-sm font-600 text-white">Find jobs</button>
              </div>
              <div className="flex flex-wrap items-center gap-2 px-2 py-2 text-[12px] text-muted-foreground">
                <span>Popular:</span>
                {["Admin Clerk", "Software Engineer", "Nurse", "Sales Executive", "F&B"].map((t) => (
                  <button key={t} className="rounded-full border border-border px-2.5 py-0.5 hover:border-primary hover:text-primary">{t}</button>
                ))}
              </div>
            </div>

            <div className="mt-6 flex flex-wrap items-center gap-4 text-[12px] text-muted-foreground">
              <span className="inline-flex items-center gap-1.5"><ShieldCheck className="h-4 w-4 text-primary"/> Verified employers only</span>
              <span className="inline-flex items-center gap-1.5"><CheckCircle2 className="h-4 w-4 text-primary"/> Data stays on-premises</span>
              <span className="inline-flex items-center gap-1.5"><Sparkles className="h-4 w-4 text-emphasis"/> AI explanations on every result</span>
            </div>
          </div>

          {/* hero collage */}
          <div className="relative">
            <div className="overflow-hidden rounded-[18px] border border-border shadow-hero">
              <img src={teamHero} alt="Malaysian professionals collaborating" className="aspect-[5/4] w-full object-cover" width={1280} height={896} />
            </div>
            {/* floating cards */}
            <div className="absolute -left-4 top-10 hidden w-[230px] rounded-[12px] border border-border bg-card p-3 shadow-hero sm:block">
              <div className="flex items-center gap-3">
                <img src={person3} alt="" className="h-10 w-10 rounded-full object-cover" loading="lazy" />
                <div>
                  <div className="text-[13px] font-600">Aisyah · Marketing</div>
                  <div className="text-[11px] text-muted-foreground">Matched in 2 days</div>
                </div>
              </div>
              <div className="mt-3 flex items-center justify-between text-[11px]">
                <span className="text-muted-foreground">Career Signal</span>
                <span className="num font-600 text-emphasis">82</span>
              </div>
              <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-inset"><div className="h-full bg-emphasis" style={{ width: "82%" }} /></div>
            </div>
            <div className="absolute -right-4 bottom-8 hidden w-[240px] rounded-[12px] border border-border bg-card p-3 shadow-hero sm:block">
              <div className="flex items-center justify-between">
                <div className="text-[11px] font-600 uppercase tracking-wider text-muted-foreground">Jobs near you</div>
                <Badge tone="ai"><Sparkles className="h-3 w-3"/> AI</Badge>
              </div>
              <div className="mt-2 space-y-2">
                {[
                  { t: "Software Engineer", c: "Petronas Digital", l: "KL · RM 6.5k" },
                  { t: "Operations Exec", c: "MISC Berhad", l: "Selangor · RM 4.2k" },
                ].map((j) => (
                  <div key={j.t} className="rounded-[8px] bg-inset px-2.5 py-2">
                    <div className="text-[12px] font-600">{j.t}</div>
                    <div className="text-[11px] text-muted-foreground">{j.c} · {j.l}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ROLE ENTRY */}
      <section className="mx-auto max-w-[1280px] px-4 py-16 lg:px-8">
        <div className="grid gap-4 md:grid-cols-3">
          {[
            { icon: <Briefcase className="h-5 w-5"/>, t: "I'm looking for a job", d: "Build your profile, get AI-matched roles, and track every application.", to: "/signin", emp: false, cta: "Find jobs" },
            { icon: <Building2 className="h-5 w-5"/>, t: "I'm hiring talent", d: "Post vacancies, screen with AI fit-match, and book interviews faster.", to: "/signin", emp: true, cta: "Post a job" },
            { icon: <ShieldCheck className="h-5 w-5"/>, t: "Case Officer (PERKESO)", d: "Manage caseloads, oversee employers, and run market intelligence.", to: "/signin", emp: false, cta: "Officer sign-in" },
          ].map((r) => (
            <Link key={r.t} to={r.to} className="group rounded-[14px] border border-border bg-card p-6 transition-shadow hover:shadow-hero">
              <span className={`mb-4 inline-flex h-10 w-10 items-center justify-center rounded-[10px] ${r.emp ? "grad-orange text-white" : "bg-primary-soft text-primary"}`}>
                {r.icon}
              </span>
              <div className="text-[18px] font-600">{r.t}</div>
              <p className="mt-1 text-sm text-muted-foreground">{r.d}</p>
              <div className="mt-4 inline-flex items-center gap-1 text-sm font-600 text-primary group-hover:gap-2 transition-all">
                {r.cta} <ArrowRight className="h-4 w-4" />
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* PROGRAMS & EVENTS */}
      <section id="programs" className="border-y border-border bg-surface">
        <div className="mx-auto max-w-[1280px] px-4 py-16 lg:px-8">
          <div className="mb-8 flex items-end justify-between gap-4">
            <div>
              <div className="mb-1 text-[12px] font-600 uppercase tracking-wider text-emphasis">Programs & events</div>
              <h2 className="text-[28px] font-600 tracking-tight">Career Carnivals, hiring events & training near you</h2>
            </div>
            <a href="#" className="hidden text-sm font-600 text-primary md:inline">See all →</a>
          </div>
          <div className="grid gap-5 md:grid-cols-3">
            {[
              { img: eventCarnival, tag: "Career Carnival", t: "MYFutureJobs Carnival KL 2026", d: "12–14 Mar · KLCC · 120+ employers · Walk-in interviews", cta: "RSVP" },
              { img: eventTraining, tag: "Training", t: "Industrial Automation Bootcamp", d: "4 weeks · Penang · HRDC-claimable · Cert on completion", cta: "Apply" },
              { img: teamHero, tag: "Hiring Event", t: "Tech & Digital Hiring Day", d: "28 Feb · Cyberjaya · 30+ tech employers", cta: "Register" },
            ].map((e) => (
              <article key={e.t} className="overflow-hidden rounded-[14px] border border-border bg-card shadow-card">
                <img src={e.img} alt="" className="aspect-[16/10] w-full object-cover" loading="lazy" />
                <div className="p-5">
                  <Badge tone="primary">{e.tag}</Badge>
                  <h3 className="mt-3 text-[16px] font-600">{e.t}</h3>
                  <p className="mt-1 text-[13px] text-muted-foreground">{e.d}</p>
                  <button className="mt-4 inline-flex h-9 items-center rounded-[10px] border border-border bg-card px-4 text-[13px] font-600 hover:border-primary hover:text-primary">
                    {e.cta} →
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* CAREER SERVICES GRID */}
      <section id="services" className="mx-auto max-w-[1280px] px-4 py-16 lg:px-8">
        <div className="mb-8">
          <div className="mb-1 text-[12px] font-600 uppercase tracking-wider text-emphasis">Career services</div>
          <h2 className="text-[28px] font-600 tracking-tight">A complete toolkit for your career, free for all Malaysians</h2>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[
            { icon: <Sparkles/>, t: "Career Signal Score", d: "Know exactly where you stand vs. the market — and how to improve." },
            { icon: <BarChart3/>, t: "CV Market Positioning", d: "AI critique with side-by-side rewrites and tracked changes." },
            { icon: <GraduationCap/>, t: "Training Pathways", d: "Certifications mapped to roles you want, not roles you don't." },
            { icon: <Award/>, t: "Interview Rewards", d: "Transport vouchers when you attend interviews via the portal." },
            { icon: <Users/>, t: "Verified Employers", d: "Every company is screened by PERKESO before posting." },
            { icon: <Calendar/>, t: "Events & Carnivals", d: "RSVP, walk-in interviews and on-site hiring across Malaysia." },
            { icon: <Briefcase/>, t: "Application Tracker", d: "Applied → Interview → KIV → Hired. Never lose track again." },
            { icon: <ShieldCheck/>, t: "On-prem AI, anonymised", d: "Your data never leaves PERKESO infrastructure." },
          ].map((s) => (
            <div key={s.t} className="rounded-[12px] border border-border bg-card p-5">
              <span className="mb-3 inline-flex h-9 w-9 items-center justify-center rounded-[8px] bg-primary-soft text-primary">{s.icon}</span>
              <div className="text-[15px] font-600">{s.t}</div>
              <p className="mt-1 text-[13px] leading-relaxed text-muted-foreground">{s.d}</p>
            </div>
          ))}
        </div>
      </section>

      {/* TESTIMONIAL STRIP */}
      <section className="border-y border-border bg-surface">
        <div className="mx-auto max-w-[1280px] px-4 py-16 lg:px-8">
          <div className="mb-8">
            <div className="mb-1 text-[12px] font-600 uppercase tracking-wider text-emphasis">Real stories</div>
            <h2 className="text-[28px] font-600 tracking-tight">From job-seekers and employers across Malaysia</h2>
          </div>
          <div className="grid gap-5 md:grid-cols-3">
            {[
              { img: person1, n: "Nurul Aiman", r: "Marketing Exec, KL", q: "The AI told me exactly which 3 skills to add to my CV. Got 4 callbacks in two weeks." },
              { img: person2, n: "Daniel Tan", r: "Software Engineer, Penang", q: "Career Signal Score made me realise I was underselling myself. Pay jump of 28% on my next role." },
              { img: person4, n: "Mr. Suresh", r: "HR Lead, Subang", q: "Fit-Match cut our shortlisting time from 3 days to 4 hours. Bias flags caught wording I'd missed." },
            ].map((t) => (
              <figure key={t.n} className="rounded-[14px] border border-border bg-card p-5 shadow-card">
                <blockquote className="text-[15px] leading-relaxed">"{t.q}"</blockquote>
                <figcaption className="mt-4 flex items-center gap-3">
                  <img src={t.img} alt="" className="h-10 w-10 rounded-full object-cover" loading="lazy" />
                  <div>
                    <div className="text-[13px] font-600">{t.n}</div>
                    <div className="text-[11px] text-muted-foreground">{t.r}</div>
                  </div>
                </figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section id="employers" className="mx-auto max-w-[1280px] px-4 py-16 lg:px-8">
        <div className="overflow-hidden rounded-[18px] border border-border bg-card p-8 shadow-hero lg:p-12">
          <div className="grid items-center gap-8 lg:grid-cols-[1.4fr_1fr]">
            <div>
              <div className="mb-2 text-[12px] font-600 uppercase tracking-wider text-emphasis">Get started — free</div>
              <h2 className="text-[36px] font-700 leading-tight tracking-tight">Three minutes to your first AI-matched job.</h2>
              <p className="mt-3 max-w-lg text-[15px] text-muted-foreground">No fees, no spam, no agency middlemen. Built and run by PERKESO for every Malaysian.</p>
              <div className="mt-6 flex flex-wrap gap-3">
                <Link to="/signin" className="inline-flex h-11 items-center rounded-[10px] grad-orange px-6 text-sm font-600 text-white">Create your account →</Link>
                <Link to="/signin" className="inline-flex h-11 items-center rounded-[10px] border border-border bg-card px-6 text-sm font-600">I'm an employer</Link>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {[
                { k: "Verified employers", v: "8,400+" },
                { k: "Open vacancies", v: "62k" },
                { k: "Trainings live", v: "320" },
                { k: "Avg. time to hire", v: "9 days" },
              ].map((s, i) => (
                <div key={s.k} className={`rounded-[12px] p-4 ${i === 1 ? "grad-orange text-white" : "border border-border bg-inset"}`}>
                  <div className={`text-[11px] font-600 uppercase tracking-wide ${i===1 ? "text-white/90" : "text-muted-foreground"}`}>{s.k}</div>
                  <div className={`num mt-1 text-[26px] font-600 ${i===1 ? "text-white" : "text-foreground"}`}>{s.v}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <footer className="border-t border-border bg-surface">
        <div className="mx-auto flex max-w-[1280px] flex-col gap-4 px-4 py-10 lg:flex-row lg:items-center lg:justify-between lg:px-8">
          <Logo />
          <div className="text-[12px] text-muted-foreground">© 2026 MYFutureJobs. Operated under PERKESO for the people of Malaysia.</div>
          <div className="flex gap-4 text-[12px] text-muted-foreground">
            <a href="#" className="hover:text-foreground">Privacy</a>
            <a href="#" className="hover:text-foreground">Accessibility</a>
            <a href="#" className="hover:text-foreground">Contact</a>
          </div>
        </div>
      </footer>

      <FloatingChatbot />
    </div>
  );
}
