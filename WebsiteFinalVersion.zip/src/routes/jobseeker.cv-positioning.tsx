import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { AIPanel } from "@/components/AIPanel";
import { jobseekerNav } from "@/lib/nav";
import { jobseekerUser } from "@/lib/mock";
import { ScoreCard, Badge, SectionTitle, KPITile } from "@/components/ui-bits";
import { Sparkles, TrendingUp, DollarSign, Briefcase } from "lucide-react";

export const Route = createFileRoute("/jobseeker/cv-positioning")({
  head: () => ({ meta: [{ title: "CV Market Positioning — MYFutureJobs" }] }),
  component: Page,
});

function Page() {
  return (
    <AppShell
      nav={jobseekerNav}
      user={jobseekerUser}
      rightPanel={
        <AIPanel
          title="Career Assistant"
          subtitle="CV positioning analysis"
          why={
            <div>
              <p>Salary benchmark uses last 90 days of verified MYFutureJobs offers in <b>Marketing · KL/Selangor · 5–7 yrs</b>.</p>
              <p className="mt-2">Confidence band reflects sample size (n=412).</p>
            </div>
          }
        >
          <div className="space-y-3">
            <div className="rounded-[10px] bg-emphasis-soft p-3">
              <div className="text-[11px] font-600 uppercase tracking-wider text-emphasis">Headline finding</div>
              <p className="mt-1 text-[12px] leading-relaxed">You're <b>underpaid by ~RM 1,200/mo</b> for your skill profile in your region.</p>
            </div>
            <div className="rounded-[10px] border border-border p-3">
              <div className="text-[12px] font-600">Roles you're underselling for</div>
              <ul className="mt-2 space-y-1 text-[12px] text-muted-foreground">
                <li>· Senior Brand Manager (RM 7.5k+)</li>
                <li>· Growth Marketing Lead (RM 8k+)</li>
                <li>· MarTech Specialist (RM 7k+)</li>
              </ul>
            </div>
          </div>
        </AIPanel>
      }
    >
      <div className="mb-6">
        <div className="text-[12px] font-600 uppercase tracking-wider text-emphasis">Career Assistant</div>
        <h1 className="text-[28px] font-700 tracking-tight">CV Market Positioning</h1>
      </div>

      <div className="grid gap-4 lg:grid-cols-[1.1fr_1fr_1fr]">
        <ScoreCard value={68} band="Strong" label="Positioning Score" />
        <KPITile label="Market salary fit" value="P58" delta="Below your skill level" icon={<DollarSign className="h-4 w-4"/>} emphasis />
        <KPITile label="Matched role count" value="142" delta="+24 with suggested changes" icon={<Briefcase className="h-4 w-4"/>} />
      </div>

      <div className="mt-6 rounded-[12px] border border-border bg-card p-6 shadow-card">
        <SectionTitle kicker="Salary benchmark" title="Marketing · KL/Selangor · 5–7 yrs (n=412)" action={<Badge tone="ai"><Sparkles className="h-3 w-3"/> AI</Badge>}/>
        <div className="relative h-24 rounded-[10px] bg-inset px-4">
          <div className="absolute inset-y-4 left-[20%] right-[15%] rounded-md grad-blue opacity-90" />
          <div className="absolute inset-y-2 left-[55%] flex flex-col items-center">
            <div className="rounded bg-emphasis px-2 py-0.5 text-[10px] font-600 text-white">YOU · RM 5,200</div>
            <div className="mt-1 h-16 w-0.5 bg-emphasis" />
          </div>
          <div className="absolute inset-y-2 left-[72%] flex flex-col items-center">
            <div className="rounded bg-foreground px-2 py-0.5 text-[10px] font-600 text-background">Market avg · RM 6,400</div>
            <div className="mt-1 h-16 w-0.5 bg-foreground" />
          </div>
        </div>
        <div className="mt-2 flex justify-between text-[11px] text-muted-foreground">
          <span>RM 3.8k</span><span>RM 5k</span><span>RM 6.5k</span><span>RM 8k</span><span>RM 10k</span>
        </div>
        <p className="mt-4 text-[13px] leading-relaxed text-muted-foreground">
          Your current package sits at <b>P58</b>. Profiles with similar skill graphs are typically offered between <b>RM 6,400 – 7,800</b>. Confidence: <span className="text-emphasis font-600">High</span>.
        </p>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <div className="rounded-[12px] border border-border bg-card p-6 shadow-card">
          <SectionTitle title="Required skills (have / missing)" />
          <div className="flex flex-wrap gap-2">
            {["SEO","Content","Brand","Stakeholder mgmt","Reporting","Campaign exec"].map((s) => (
              <span key={s} className="rounded-full bg-primary-soft px-3 py-1 text-[12px] font-600 text-primary">✓ {s}</span>
            ))}
            {["SQL","Looker","HubSpot","A/B testing"].map((s) => (
              <span key={s} className="rounded-full border border-dashed border-emphasis bg-emphasis-soft px-3 py-1 text-[12px] font-600 text-emphasis">+ {s}</span>
            ))}
          </div>
        </div>
        <div className="rounded-[12px] border border-border bg-card p-6 shadow-card">
          <SectionTitle title="Hot, preferred & implicit skills" />
          <ul className="space-y-2 text-[13px]">
            <li className="flex items-center justify-between rounded-[8px] bg-inset px-3 py-2"><span className="flex items-center gap-2"><TrendingUp className="h-4 w-4 text-emphasis"/> AI prompt design</span><Badge tone="emphasis">Hot · trending</Badge></li>
            <li className="flex items-center justify-between rounded-[8px] bg-inset px-3 py-2"><span>Marketing automation</span><Badge tone="primary">Preferred</Badge></li>
            <li className="flex items-center justify-between rounded-[8px] bg-inset px-3 py-2"><span>Data storytelling</span><Badge tone="default">Implicit · most JDs imply</Badge></li>
            <li className="flex items-center justify-between rounded-[8px] bg-inset px-3 py-2"><span>Cross-cultural campaigns</span><Badge tone="default">Implicit</Badge></li>
          </ul>
        </div>
      </div>
    </AppShell>
  );
}
