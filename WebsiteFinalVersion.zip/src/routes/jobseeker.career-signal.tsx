import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { AIPanel } from "@/components/AIPanel";
import { jobseekerNav } from "@/lib/nav";
import { jobseekerUser } from "@/lib/mock";
import { ScoreCard, KPITile, Badge, SectionTitle } from "@/components/ui-bits";
import { TrendingUp, Sparkles, Target, BarChart3 } from "lucide-react";

export const Route = createFileRoute("/jobseeker/career-signal")({
  head: () => ({ meta: [{ title: "Career Signal — MYFutureJobs" }] }),
  component: Page,
});

const dims = [
  { name: "Skills coverage", score: 78, peer: 71 },
  { name: "Experience relevance", score: 82, peer: 70 },
  { name: "Credentials", score: 60, peer: 68 },
  { name: "Activity & recency", score: 88, peer: 72 },
  { name: "Profile completeness", score: 82, peer: 80 },
];

function Page() {
  return (
    <AppShell
      nav={jobseekerNav}
      user={jobseekerUser}
      rightPanel={
        <AIPanel
          title="Career Assistant"
          subtitle="Score explainer"
          why={
            <div className="space-y-2">
              <p>Your Career Signal of <b>74</b> is based on:</p>
              <ul className="list-disc pl-4">
                <li>Skill match against 4,200 active Senior Marketing roles in MY</li>
                <li>Peer benchmark: 312 anonymised profiles with similar experience</li>
                <li>Activity over the last 30 days</li>
              </ul>
              <p className="pt-1">All data processed on-prem and anonymised.</p>
            </div>
          }
        >
          <div className="space-y-3">
            <div className="rounded-[10px] border border-border p-3">
              <div className="text-[11px] font-600 uppercase tracking-wider text-emphasis">Biggest lever</div>
              <div className="mt-1 text-[13px] font-600">Add 2 credentials</div>
              <p className="mt-1 text-[12px] text-muted-foreground">Could move you to <b>Strong</b> (target 82).</p>
            </div>
            {[
              { t: "Add SQL skill", d: "+6 score · unlocks 18 roles" },
              { t: "Take Digital Analytics cert", d: "+9 score · unlocks 24 roles" },
              { t: "Refresh CV summary", d: "+3 score · 5 minutes" },
            ].map((s, i) => (
              <button key={i} className="w-full rounded-[10px] border border-border p-3 text-left hover:border-primary hover:bg-primary-soft">
                <div className="text-[13px] font-600">{s.t}</div>
                <div className="text-[11px] text-muted-foreground">{s.d}</div>
              </button>
            ))}
          </div>
        </AIPanel>
      }
    >
      <div className="mb-6">
        <div className="text-[12px] font-600 uppercase tracking-wider text-emphasis">Career Assistant</div>
        <h1 className="text-[28px] font-700 tracking-tight">Career Signal & Scoring</h1>
        <p className="mt-1 text-sm text-muted-foreground">Where you stand against the market, and exactly how to climb.</p>
      </div>

      <div className="grid gap-4 lg:grid-cols-[1.2fr_1fr_1fr]">
        <ScoreCard value={74} band="Competitive" />
        <KPITile label="Peer percentile" value="68th" delta="Top third in your role" icon={<Target className="h-4 w-4" />} />
        <KPITile label="Trend (90d)" value="+11" delta="Consistently improving" icon={<TrendingUp className="h-4 w-4" />} emphasis />
      </div>

      <div className="mt-6 rounded-[12px] border border-border bg-card p-6 shadow-card">
        <SectionTitle kicker="Breakdown" title="Score by dimension" action={<Badge tone="ai"><Sparkles className="h-3 w-3"/> AI</Badge>} />
        <div className="space-y-5">
          {dims.map((d, i) => (
            <div key={d.name}>
              <div className="mb-1.5 flex items-center justify-between text-[13px]">
                <span className="font-600">{d.name}</span>
                <span className="num text-muted-foreground">You {d.score} · Peers {d.peer}</span>
              </div>
              <div className="relative h-2.5 overflow-hidden rounded-full bg-inset">
                <div
                  className="absolute inset-y-0 left-0 rounded-full"
                  style={{ width: `${d.score}%`, background: i === 0 ? "var(--emphasis)" : "var(--primary)" }}
                />
                <div
                  className="absolute top-1/2 h-3 w-0.5 -translate-y-1/2 bg-foreground/40"
                  style={{ left: `${d.peer}%` }}
                  aria-label="Peer benchmark"
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <div className="rounded-[12px] border border-border bg-card p-6 shadow-card">
          <SectionTitle title="Market positioning" />
          <div className="flex h-44 items-end gap-2">
            {[42, 55, 60, 68, 74, 78, 82, 88].map((v, i) => (
              <div key={i} className="relative flex-1 rounded-t-md" style={{ height: `${v}%`, background: i === 4 ? "var(--emphasis)" : "var(--primary)" }}>
                {i === 4 && (
                  <div className="absolute -top-7 left-1/2 -translate-x-1/2 rounded bg-emphasis px-1.5 py-0.5 text-[10px] font-600 text-white">YOU</div>
                )}
              </div>
            ))}
          </div>
          <div className="mt-2 flex justify-between text-[10px] text-muted-foreground">
            <span>P10</span><span>P25</span><span>P40</span><span>P55</span><span>P68</span><span>P80</span><span>P92</span><span>P99</span>
          </div>
        </div>
        <div className="rounded-[12px] border border-border bg-card p-6 shadow-card">
          <SectionTitle title="What lifts your score" />
          <ul className="space-y-3 text-[13px]">
            {[
              { t: "Add SQL skill", v: "+6", c: "emphasis" },
              { t: "Complete Digital Analytics cert", v: "+9", c: "primary" },
              { t: "Add measurable wins to CV", v: "+4", c: "primary" },
              { t: "Refresh activity (apply this week)", v: "+2", c: "primary" },
            ].map((r) => (
              <li key={r.t} className="flex items-center justify-between rounded-[8px] border border-border px-3 py-2.5">
                <span className="flex items-center gap-2"><BarChart3 className="h-4 w-4 text-muted-foreground"/> {r.t}</span>
                <span className={`num font-600 ${r.c === "emphasis" ? "text-emphasis" : "text-primary"}`}>{r.v}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </AppShell>
  );
}
