import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { AppShell } from "@/components/AppShell";
import { AIPanel } from "@/components/AIPanel";
import { employerNav } from "@/lib/nav";
import { employerUser, candidates } from "@/lib/mock";
import { Badge, SectionTitle } from "@/components/ui-bits";
import { Sparkles, ArrowRight } from "lucide-react";

export const Route = createFileRoute("/employer/fit-match")({
  head: () => ({ meta: [{ title: "Fit-Match — MYFutureJobs" }] }),
  component: Page,
});

function Page() {
  const [active, setActive] = useState(candidates[0]);
  const dims = [
    { name: "Leadership", v: 72 },
    { name: "Cultural Fit", v: 80 },
    { name: "Experience", v: 88 },
    { name: "Technical Skills", v: 95 },
    { name: "Industry", v: 76 },
  ];
  const top = dims.reduce((a, b) => (b.v > a.v ? b : a));
  return (
    <AppShell
      nav={employerNav}
      user={employerUser}
      rightPanel={
        <AIPanel title="Hiring Assistant" subtitle={`Fit deep-dive · ${active.name}`} why={<div>
          <p>Fit-Match weights tuned to this JD:</p>
          <ul className="mt-1 list-disc pl-4">
            <li>Technical 35% · Experience 25% · Leadership 15% · Industry 15% · Culture 10%</li>
          </ul>
          <p className="mt-2">Edit weights from JD Analysis → Evaluation Criteria.</p>
        </div>}>
          <div className="space-y-3">
            <div className="rounded-[10px] bg-emphasis-soft p-3">
              <div className="text-[11px] font-600 uppercase tracking-wider text-emphasis">Recommendation</div>
              <p className="mt-1 text-[12px]">Move to interview — top match this week.</p>
            </div>
            <button className="inline-flex h-9 w-full items-center justify-center rounded-[10px] grad-orange text-[12px] font-600 text-white">
              Schedule interview
            </button>
            <button className="inline-flex h-9 w-full items-center justify-center rounded-[10px] border border-border bg-card text-[12px] font-600">
              Generate interview pack
            </button>
          </div>
        </AIPanel>
      }
    >
      <div className="mb-6">
        <div className="text-[12px] font-600 uppercase tracking-wider text-emphasis">Hiring Assistant</div>
        <h1 className="text-[28px] font-700 tracking-tight">Fit-Match · Software Engineer (Backend)</h1>
      </div>

      <div className="grid gap-4 lg:grid-cols-[1fr_1.5fr]">
        <section className="rounded-[12px] border border-border bg-card p-3 shadow-card">
          <div className="mb-2 px-2 pt-1 text-[12px] font-600 uppercase tracking-wider text-muted-foreground">Shortlist · 12</div>
          <ul className="space-y-1">
            {candidates.map((c) => (
              <li key={c.id}>
                <button onClick={() => setActive(c)} className={`flex w-full items-center gap-3 rounded-[10px] p-2.5 text-left ${active.id === c.id ? "bg-primary-soft" : "hover:bg-inset"}`}>
                  <img src={c.avatar} alt="" className="h-9 w-9 rounded-full object-cover"/>
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-[13px] font-600">{c.name}</div>
                    <div className="truncate text-[11px] text-muted-foreground">{c.role} · {c.exp}</div>
                  </div>
                  <div className="text-right">
                    <div className="num text-[15px] font-600 text-emphasis">{c.fit}</div>
                  </div>
                </button>
              </li>
            ))}
          </ul>
        </section>

        <section className="rounded-[12px] border border-border bg-card p-6 shadow-card">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div className="flex items-center gap-3">
              <img src={active.avatar} alt="" className="h-14 w-14 rounded-full object-cover"/>
              <div>
                <div className="text-[18px] font-600">{active.name}</div>
                <div className="text-[13px] text-muted-foreground">{active.role} · {active.exp} · {active.loc}</div>
              </div>
            </div>
            <div className="text-right">
              <div className="num text-[40px] font-600 leading-none text-emphasis">{active.fit}</div>
              <div className="text-[12px] text-muted-foreground">Fit-Match score</div>
            </div>
          </div>

          <div className="mt-6 space-y-4">
            {dims.map((d) => {
              const isTop = d.name === top.name;
              return (
                <div key={d.name}>
                  <div className="mb-1.5 flex items-center justify-between text-[13px]">
                    <span className="font-600">{d.name} {isTop && <Badge tone="emphasis">Strongest</Badge>}</span>
                    <span className="num">{d.v}</span>
                  </div>
                  <div className="h-2 overflow-hidden rounded-full bg-inset">
                    <div className="h-full rounded-full" style={{ width: `${d.v}%`, background: isTop ? "var(--emphasis)" : "var(--primary)" }}/>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-6 grid gap-4 md:grid-cols-2">
            <div className="rounded-[10px] border border-border p-4">
              <div className="text-[12px] font-600 uppercase tracking-wider text-muted-foreground">Why a strong match</div>
              <ul className="mt-2 list-disc space-y-1 pl-4 text-[13px]">
                <li>5 yrs Go/PostgreSQL at scale (fintech)</li>
                <li>Led migration project — matches scope</li>
                <li>Based in Cyberjaya, hybrid-friendly</li>
              </ul>
            </div>
            <div className="rounded-[10px] border border-border p-4">
              <div className="text-[12px] font-600 uppercase tracking-wider text-muted-foreground">Gaps</div>
              <ul className="mt-2 list-disc space-y-1 pl-4 text-[13px]">
                <li>No prior team-lead title (only informal mentorship)</li>
                <li>Limited exposure to payments domain</li>
              </ul>
            </div>
          </div>

          <div className="mt-6 flex justify-end gap-2">
            <button className="inline-flex h-10 items-center rounded-[10px] border border-border px-4 text-sm font-600">Reject</button>
            <button className="inline-flex h-10 items-center rounded-[10px] bg-primary px-4 text-sm font-600 text-primary-foreground">Move to interview <ArrowRight className="ml-1 h-4 w-4"/></button>
          </div>
        </section>
      </div>
    </AppShell>
  );
}
