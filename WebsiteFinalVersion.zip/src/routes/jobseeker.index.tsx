import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { jobseekerNav } from "@/lib/nav";
import { jobseekerUser, jobs } from "@/lib/mock";
import { KPITile, ScoreCard, SectionTitle, Badge } from "@/components/ui-bits";
import { AIPanel } from "@/components/AIPanel";
import { Briefcase, Eye, Send, CheckCircle2, Sparkles, ArrowRight, GraduationCap, MapPin, TrendingUp } from "lucide-react";
import eventCarnival from "@/assets/event-carnival.jpg";

export const Route = createFileRoute("/jobseeker/")({
  head: () => ({ meta: [{ title: "Jobseeker dashboard — MYFutureJobs" }] }),
  component: Dashboard,
});

function Dashboard() {
  return (
    <AppShell
      nav={jobseekerNav}
      user={jobseekerUser}
      rightPanel={
        <AIPanel
          title="Career Assistant"
          subtitle="Daily next-best-action"
          why={
            <div className="space-y-2">
              <p>Your "Add SQL" suggestion is based on:</p>
              <ul className="list-disc pl-4">
                <li>72% of Senior Marketing roles you viewed list SQL as preferred.</li>
                <li>Peers at +1 band have SQL on their profile (sample: 312 profiles).</li>
                <li>Adding it typically lifts Career Signal by +6–9 points.</li>
              </ul>
            </div>
          }
        >
          <div className="space-y-4">
            <div className="rounded-[10px] bg-emphasis-soft p-3">
              <div className="text-[11px] font-600 uppercase tracking-wider text-emphasis">Today's focus</div>
              <div className="mt-1 text-[14px] font-600">Add SQL to your skill set</div>
              <p className="mt-1 text-[12px] text-muted-foreground">Could lift your Career Signal by ~+7 and unlock 18 more matched roles.</p>
              <button className="mt-3 inline-flex h-8 items-center rounded-[8px] grad-orange px-3 text-[12px] font-600 text-white">
                Add to profile
              </button>
            </div>

            <div>
              <div className="mb-2 text-[12px] font-600 text-muted-foreground">Suggested for you this week</div>
              <ul className="space-y-2">
                {[
                  "Apply to Senior Marketing Exec at Petronas Digital (94% match)",
                  "Complete 'Digital Analytics' micro-cert (4 hrs, HRDC-claimable)",
                  "RSVP MYFutureJobs Carnival KL · 12 Mar",
                  "Update profile photo for +12% recruiter view rate",
                ].map((t, i) => (
                  <li key={i} className="flex items-start gap-2 rounded-[8px] border border-border p-2.5">
                    <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary-soft text-[11px] font-600 text-primary">{i + 1}</span>
                    <span className="text-[12px] leading-relaxed">{t}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </AIPanel>
      }
    >
      <div className="mb-6">
        <div className="text-[12px] font-600 uppercase tracking-wider text-emphasis">Good morning, Nurul</div>
        <h1 className="text-[28px] font-700 tracking-tight">Your career, on track.</h1>
      </div>

      {/* KPI row */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <KPITile label="Applications" value="12" delta="+3 this week" icon={<Send className="h-4 w-4" />} />
        <KPITile label="Profile views" value="148" delta="+22 last 7d" icon={<Eye className="h-4 w-4" />} />
        <KPITile label="Interviews" value="3" delta="2 upcoming" icon={<Briefcase className="h-4 w-4" />} />
        <KPITile label="Career Signal" value="74" delta="Competitive · +6 last month" emphasis gradient icon={<Sparkles className="h-4 w-4" />} />
      </div>

      {/* Score + completion */}
      <div className="mt-6 grid gap-4 lg:grid-cols-[1.2fr_1fr]">
        <ScoreCard value={74} band="Competitive" />
        <div className="rounded-[10px] border border-border bg-card p-6 shadow-card">
          <div className="text-[12px] font-600 uppercase tracking-wider text-muted-foreground">Profile completion</div>
          <div className="mt-4 flex items-center gap-5">
            <div className="relative h-24 w-24">
              <svg viewBox="0 0 100 100" className="h-24 w-24 -rotate-90">
                <circle cx="50" cy="50" r="44" stroke="var(--inset)" strokeWidth="10" fill="none" />
                <circle cx="50" cy="50" r="44" stroke="var(--primary)" strokeWidth="10" fill="none" strokeDasharray={`${(82/100)*276} 276`} strokeLinecap="round" />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center text-[18px] font-600">82%</div>
            </div>
            <div className="flex-1 space-y-1.5 text-[13px]">
              {[
                ["Basics", true], ["Experience", true], ["Skills", true], ["Certifications", false], ["Portfolio links", false],
              ].map(([t, ok]) => (
                <div key={t as string} className="flex items-center justify-between">
                  <span className={ok ? "text-foreground" : "text-muted-foreground"}>{t as string}</span>
                  {ok ? <CheckCircle2 className="h-4 w-4 text-[var(--success)]"/> : <span className="text-[11px] text-primary font-600">Add →</span>}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Jobs for you */}
      <div className="mt-8">
        <SectionTitle
          kicker="Recommended"
          title="Jobs for you"
          action={<Link to="/jobseeker/jobs" className="text-sm font-600 text-primary">View all →</Link>}
        />
        <div className="grid gap-3 lg:grid-cols-2">
          {jobs.map((j) => (
            <article key={j.id} className="rounded-[12px] border border-border bg-card p-4 shadow-card transition-shadow hover:shadow-hero">
              <div className="flex items-start gap-3">
                <div className="flex h-11 w-11 items-center justify-center rounded-[10px] bg-inset text-xl">{j.logo}</div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="truncate text-[15px] font-600">{j.title}</h3>
                    <Badge tone="ai"><Sparkles className="h-3 w-3" /> {j.match}% match</Badge>
                  </div>
                  <div className="mt-0.5 truncate text-[13px] text-muted-foreground">{j.company}</div>
                  <div className="mt-2 flex flex-wrap gap-3 text-[12px] text-muted-foreground">
                    <span className="inline-flex items-center gap-1"><MapPin className="h-3 w-3"/>{j.loc}</span>
                    <span>{j.pay}</span>
                    <span>{j.type}</span>
                    <span>· {j.posted} ago</span>
                  </div>
                </div>
              </div>
              <div className="mt-3 flex items-center justify-between gap-2">
                <button className="text-[12px] font-600 text-primary">View · Why this match →</button>
                <button className="inline-flex h-9 items-center rounded-[8px] bg-primary px-3 text-[12px] font-600 text-primary-foreground">Quick apply</button>
              </div>
            </article>
          ))}
        </div>
      </div>

      {/* Pipeline + Training */}
      <div className="mt-8 grid gap-4 lg:grid-cols-[1.3fr_1fr]">
        <div className="rounded-[12px] border border-border bg-card p-5 shadow-card">
          <SectionTitle title="Application snapshot" />
          <div className="grid grid-cols-4 gap-2">
            {[
              { s: "Applied", n: 12, c: "var(--muted-foreground)" },
              { s: "Interview", n: 3, c: "var(--primary)" },
              { s: "KIV", n: 2, c: "var(--warning)" },
              { s: "Offer", n: 1, c: "var(--success)" },
            ].map((p) => (
              <div key={p.s} className="rounded-[10px] bg-inset p-3 text-center">
                <div className="num text-[24px] font-600" style={{ color: p.c }}>{p.n}</div>
                <div className="mt-1 text-[11px] uppercase tracking-wider text-muted-foreground">{p.s}</div>
              </div>
            ))}
          </div>
          <div className="mt-4 space-y-2">
            {[
              { c: "Petronas Digital", r: "Sr. Marketing Exec", s: "Interview · Thu 14 Feb 10:00" },
              { c: "Maybank", r: "Digital Campaign Lead", s: "Applied · awaiting response" },
              { c: "AirAsia", r: "Brand Specialist", s: "KIV · review in 7 days" },
            ].map((a) => (
              <div key={a.r} className="flex items-center justify-between rounded-[10px] border border-border p-3 text-[13px]">
                <div>
                  <div className="font-600">{a.r}</div>
                  <div className="text-[12px] text-muted-foreground">{a.c} · {a.s}</div>
                </div>
                <ArrowRight className="h-4 w-4 text-muted-foreground" />
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-[12px] border border-border bg-card p-5 shadow-card">
          <SectionTitle kicker="AI suggested" title="Training to unlock more roles" />
          <div className="overflow-hidden rounded-[10px] border border-border">
            <img src={eventCarnival} alt="" className="aspect-[16/9] w-full object-cover" loading="lazy"/>
          </div>
          <div className="mt-3 space-y-3">
            {[
              { t: "Digital Analytics Foundations", d: "4 hours · HRDC", impact: "+18 matched roles" },
              { t: "SQL for Marketers", d: "8 hours · Cert", impact: "+24 matched roles" },
            ].map((t) => (
              <div key={t.t} className="flex items-start gap-3">
                <span className="mt-0.5 flex h-9 w-9 items-center justify-center rounded-[8px] bg-primary-soft text-primary">
                  <GraduationCap className="h-4 w-4"/>
                </span>
                <div className="flex-1">
                  <div className="text-[13px] font-600">{t.t}</div>
                  <div className="text-[11px] text-muted-foreground">{t.d}</div>
                  <div className="mt-0.5 inline-flex items-center gap-1 text-[11px] font-600 text-emphasis">
                    <TrendingUp className="h-3 w-3"/> {t.impact}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </AppShell>
  );
}
