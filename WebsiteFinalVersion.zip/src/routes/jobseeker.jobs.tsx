import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { jobseekerNav } from "@/lib/nav";
import { jobseekerUser, jobs } from "@/lib/mock";
import { Badge } from "@/components/ui-bits";
import { Search, MapPin, Sliders, Sparkles, Bookmark } from "lucide-react";

export const Route = createFileRoute("/jobseeker/jobs")({
  head: () => ({ meta: [{ title: "Find jobs — MYFutureJobs" }] }),
  component: Page,
});

function Page() {
  const allJobs = [...jobs, ...jobs.map((j) => ({ ...j, id: j.id + "x", match: j.match - 7 }))];
  return (
    <AppShell nav={jobseekerNav} user={jobseekerUser}>
      <div className="mb-6">
        <h1 className="text-[28px] font-700 tracking-tight">Find jobs</h1>
        <p className="mt-1 text-sm text-muted-foreground">{allJobs.length} matches · sorted by AI fit</p>
      </div>

      <div className="rounded-[12px] border border-border bg-card p-3 shadow-card">
        <div className="grid gap-2 md:grid-cols-[1.5fr_1fr_1fr_auto]">
          <label className="flex items-center gap-2 rounded-[10px] bg-inset px-3">
            <Search className="h-4 w-4 text-muted-foreground"/>
            <input defaultValue="Marketing" className="h-11 w-full bg-transparent text-sm outline-none"/>
          </label>
          <label className="flex items-center gap-2 rounded-[10px] bg-inset px-3">
            <MapPin className="h-4 w-4 text-muted-foreground"/>
            <input defaultValue="Kuala Lumpur" className="h-11 w-full bg-transparent text-sm outline-none"/>
          </label>
          <select className="h-11 rounded-[10px] bg-inset px-3 text-sm">
            <option>Any salary</option><option>RM 4k+</option><option>RM 6k+</option><option>RM 8k+</option>
          </select>
          <button className="h-11 rounded-[10px] bg-primary px-5 text-sm font-600 text-primary-foreground">Search</button>
        </div>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-[260px_1fr]">
        <aside className="space-y-5 rounded-[12px] border border-border bg-card p-5 shadow-card lg:sticky lg:top-24 lg:self-start">
          <div className="flex items-center justify-between"><div className="text-[14px] font-600">Filters</div><Sliders className="h-4 w-4 text-muted-foreground"/></div>
          {[
            { t: "Job type", o: ["Full-time", "Part-time", "Contract", "Internship"] },
            { t: "Experience", o: ["Entry", "Mid", "Senior", "Lead"] },
            { t: "Industry", o: ["Tech", "Finance", "F&B", "Healthcare", "Govt"] },
          ].map((g) => (
            <div key={g.t}>
              <div className="mb-2 text-[12px] font-600 uppercase tracking-wider text-muted-foreground">{g.t}</div>
              <div className="space-y-1.5">
                {g.o.map((o) => (
                  <label key={o} className="flex items-center gap-2 text-[13px]">
                    <input type="checkbox" className="h-4 w-4 rounded border-border accent-[var(--primary)]"/> {o}
                  </label>
                ))}
              </div>
            </div>
          ))}
          <button className="w-full rounded-[10px] border border-border py-2 text-[12px] font-600 text-muted-foreground">Reset</button>
        </aside>

        <div className="space-y-3">
          {allJobs.map((j) => (
            <article key={j.id} className="rounded-[12px] border border-border bg-card p-5 shadow-card transition-shadow hover:shadow-hero">
              <div className="flex items-start gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-[10px] bg-inset text-xl">{j.logo}</div>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <h3 className="text-[16px] font-600">{j.title}</h3>
                    <div className="flex items-center gap-2">
                      <Badge tone="ai"><Sparkles className="h-3 w-3"/> {j.match}% match</Badge>
                      <button aria-label="Save"><Bookmark className="h-4 w-4 text-muted-foreground hover:text-emphasis"/></button>
                    </div>
                  </div>
                  <div className="text-[13px] text-muted-foreground">{j.company} · {j.loc}</div>
                  <div className="mt-3 flex flex-wrap gap-2 text-[12px]">
                    <Badge tone="default">{j.type}</Badge>
                    <Badge tone="default">{j.pay}</Badge>
                    <Badge tone="default">Posted {j.posted} ago</Badge>
                  </div>
                  <p className="mt-3 text-[13px] leading-relaxed text-muted-foreground">
                    Looking for a marketing professional who can lead end-to-end campaign delivery across digital channels. Strong analytical mindset and storytelling skills required.
                  </p>
                  <div className="mt-4 flex items-center justify-between">
                    <button className="text-[12px] font-600 text-primary">Why this match? →</button>
                    <div className="flex gap-2">
                      <button className="inline-flex h-9 items-center rounded-[8px] border border-border bg-card px-3 text-[12px] font-600">View</button>
                      <button className="inline-flex h-9 items-center rounded-[8px] bg-primary px-3 text-[12px] font-600 text-primary-foreground">Quick apply</button>
                    </div>
                  </div>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </AppShell>
  );
}
