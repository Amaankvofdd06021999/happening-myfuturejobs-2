import { Link, useRouterState } from "@tanstack/react-router";
import { type ReactNode } from "react";
import { Logo } from "./Logo";
import { ThemeToggle } from "./ThemeToggle";
import { Bell, Search } from "lucide-react";

export type NavItem = { to: string; label: string; icon: ReactNode };

export function AppShell({
  nav,
  user,
  children,
  rightPanel,
}: {
  nav: NavItem[];
  user: { name: string; role: string; avatar?: string };
  children: ReactNode;
  rightPanel?: ReactNode;
}) {
  const { location } = useRouterState();
  return (
    <div className="flex min-h-dvh bg-surface">
      <aside className="sticky top-0 hidden h-dvh w-[240px] shrink-0 flex-col border-r border-border bg-card lg:flex">
        <div className="border-b border-border px-5 py-4">
          <Logo />
        </div>
        <nav className="flex-1 space-y-1 p-3">
          {nav.map((n) => {
            const active = location.pathname === n.to || location.pathname.startsWith(n.to + "/");
            return (
              <Link
                key={n.to}
                to={n.to}
                className={`flex items-center gap-3 rounded-[10px] px-3 py-2.5 text-sm transition-colors ${
                  active
                    ? "bg-primary-soft text-primary font-600"
                    : "text-muted-foreground hover:bg-inset hover:text-foreground"
                }`}
              >
                <span className={active ? "text-primary" : ""}>{n.icon}</span>
                {n.label}
              </Link>
            );
          })}
        </nav>
        <div className="border-t border-border p-3">
          <div className="flex items-center gap-3 rounded-[10px] p-2">
            <div className="flex h-9 w-9 items-center justify-center overflow-hidden rounded-full bg-primary-soft text-primary font-600">
              {user.avatar ? <img src={user.avatar} alt="" className="h-full w-full object-cover" /> : user.name[0]}
            </div>
            <div className="min-w-0 flex-1">
              <div className="truncate text-sm font-600">{user.name}</div>
              <div className="truncate text-[11px] text-muted-foreground">{user.role}</div>
            </div>
          </div>
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex items-center gap-3 border-b border-border bg-card/95 px-4 py-3 backdrop-blur lg:px-8">
          <div className="lg:hidden"><Logo /></div>
          <div className="relative ml-auto hidden flex-1 max-w-md md:block">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              placeholder="Search jobs, candidates, reports…"
              className="w-full rounded-[10px] border border-border bg-inset py-2 pl-9 pr-3 text-sm outline-none focus:border-primary focus:bg-card"
            />
          </div>
          <button aria-label="Notifications" className="relative inline-flex h-10 w-10 items-center justify-center rounded-[10px] border border-border bg-card hover:bg-inset">
            <Bell className="h-4 w-4" />
            <span className="absolute right-2.5 top-2.5 h-2 w-2 rounded-full bg-emphasis" />
          </button>
          <ThemeToggle />
        </header>

        <div className="flex min-h-0 flex-1">
          <main className="min-w-0 flex-1 overflow-x-hidden p-4 lg:p-8">{children}</main>
          {rightPanel && <div className="hidden xl:block">{rightPanel}</div>}
        </div>
      </div>
    </div>
  );
}
