import { Link } from "@tanstack/react-router";

export function Logo({ className = "" }: { className?: string }) {
  return (
    <Link to="/" className={`flex items-center gap-2 ${className}`} aria-label="MYFutureJobs">
      <span className="relative flex h-8 w-8 items-center justify-center rounded-[10px] grad-blue text-white shadow-card">
        <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2.5">
          <path d="M4 14l5-5 4 4 7-7" strokeLinecap="round" strokeLinejoin="round" />
          <circle cx="20" cy="6" r="1.5" fill="#ee562d" stroke="none" />
        </svg>
      </span>
      <span className="text-[15px] font-700 tracking-tight">
        <span className="font-bold">MYFutureJobs</span>
      </span>
    </Link>
  );
}
